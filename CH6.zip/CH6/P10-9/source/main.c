#include<stdio.h>
#include<stdlib.h>
#include"Information.h"

typedef struct card Card;
void fillDeck(Card *const wDesk, const char*wFace[],
	const char *wSuit[]);
void shuffle(Card *const wDeck);
void deal(const Card *const wDeck);

int main(void)
{
	Card deck[52];
	const char *face[] = { "Ace","Deuce","Three","Four","Five"
	,"Six","Seven","Eight","Nine" ,"Ten" ,"Jack" ,"Queen" ,"King" };
	
	const char*suit[] = { "Hearts","Diamonds","Clubs","Spades" };

	srand(time(NULL));

	fillDeck(deck, face, suit);
	shuffle(deck);
	deal(deck);
	system("pause");
	return 0;
}

void fillDeck(Card *const wDesk, const char*wFace[],
	const char *wSuit[])
{
	int i;
	for (i = 0; i <= 51; i++)//�ƦC�զX
	{
		wDesk[i].face = wFace[i % 13];
		wDesk[i].suit = wSuit[i / 13];
	}
}

void shuffle(Card *const wDeck)
{
	int i;
	int j;
	Card temp;

	for (i = 0; i <= 51; i++)//�~�P
	{
		j = rand() % 52;
		temp = wDeck[i];
		wDeck[i] = wDeck[j];
		wDeck[j] = temp;
	}
}

void deal(const Card *const wDeck)
{
	int i;

	for (i = 0; i <= 51; i++)//���L
	{
		printf("%5s of %-8s%s", wDeck[i].face, wDeck[i].suit,
			(i + 1) % 4 ? " " : "\n");
	}
}