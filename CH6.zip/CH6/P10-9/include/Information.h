#include<stdio.h>

struct card
{
	const char *face;
	const char *suit;
};

